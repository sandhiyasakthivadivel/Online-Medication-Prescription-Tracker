
import { GoogleGenAI } from "@google/genai";

const getAIClient = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
};

export const generatePrescriptionSummary = async (diagnosis: string, prescriptions: any[]) => {
  const ai = getAIClient();
  const prompt = `As a helpful medical assistant, summarize this medical diagnosis and treatment for a patient in simple terms.
    Diagnosis: ${diagnosis}
    Prescriptions: ${JSON.stringify(prescriptions)}
    Provide a friendly, concise explanation of what the medication is for and any general advice. Keep it under 100 words.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Unable to generate summary at this time.";
  }
};

export const suggestDiagnosis = async (notes: string) => {
  const ai = getAIClient();
  const prompt = `Based on the following patient symptoms and consultation notes, suggest a possible medical diagnosis and a standard medication list.
    Notes: ${notes}
    Return the response in JSON format with fields: diagnosis (string), suggestions (array of objects with fields: medicine, dosage, frequency).`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });
    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("Gemini Error:", error);
    return null;
  }
};
