
import React, { useState } from 'react';
import Login from './Login';
import SignUp from './SignUp';

const AuthContainer: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-950 p-4 relative overflow-hidden">
      {/* Decorative Blobs */}
      <div className="absolute top-[-10%] left-[-10%] w-96 h-96 bg-blue-500/20 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-96 h-96 bg-indigo-500/20 rounded-full blur-3xl animate-pulse delay-700"></div>

      <div className="w-full max-w-4xl bg-white rounded-3xl shadow-2xl flex flex-col md:flex-row overflow-hidden relative z-10">
        {/* Left Side: Brand Info */}
        <div className="md:w-1/3 bg-blue-600 p-8 md:p-12 text-white flex flex-col justify-center items-center md:items-start text-center md:text-left">
          <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center text-3xl font-bold mb-6 backdrop-blur-sm">M</div>
          <h2 className="text-3xl font-bold mb-4">MedTrack Pro</h2>
          <p className="text-blue-100 mb-8 leading-relaxed">
            The complete hospital ecosystem for patients, doctors, and administrators. 
            Digitalized records, instant appointments, and integrated lab results.
          </p>
          <div className="hidden md:block space-y-4">
            <div className="flex items-center gap-3 text-sm">
              <div className="w-2 h-2 rounded-full bg-blue-300"></div>
              <span>Role-based Secure Access</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <div className="w-2 h-2 rounded-full bg-blue-300"></div>
              <span>AI Diagnosis Suggestions</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <div className="w-2 h-2 rounded-full bg-blue-300"></div>
              <span>Real-time Lab Integration</span>
            </div>
          </div>
        </div>

        {/* Right Side: Forms */}
        <div className="md:w-2/3 p-8 md:p-12">
          <div className="flex justify-center md:justify-start mb-8 border-b border-slate-100">
            <button 
              onClick={() => setIsLogin(true)}
              className={`pb-4 px-6 font-semibold transition-all ${isLogin ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-400 hover:text-slate-600'}`}
            >
              Sign In
            </button>
            <button 
              onClick={() => setIsLogin(false)}
              className={`pb-4 px-6 font-semibold transition-all ${!isLogin ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-400 hover:text-slate-600'}`}
            >
              Create Account
            </button>
          </div>

          {isLogin ? <Login /> : <SignUp onComplete={() => setIsLogin(true)} />}
        </div>
      </div>
    </div>
  );
};

export default AuthContainer;
