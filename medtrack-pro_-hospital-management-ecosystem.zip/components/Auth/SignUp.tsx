
import React, { useState } from 'react';
import { useApp } from '../../App';
import { UserRole, DoctorCategory, User } from '../../types';

interface SignUpProps {
  onComplete: () => void;
}

const SignUp: React.FC<SignUpProps> = ({ onComplete }) => {
  const { setUsers } = useApp();
  const [role, setRole] = useState<UserRole>(UserRole.PATIENT);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    specialty: DoctorCategory.GENERAL
  });
  const [error, setError] = useState('');

  const handleSignUp = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    const newUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      name: formData.name,
      email: formData.email,
      role: role,
      specialty: role === UserRole.DOCTOR ? formData.specialty : undefined
    };

    setUsers(prev => [...prev, newUser]);
    alert("Account created successfully! You can now log in.");
    onComplete();
  };

  return (
    <form onSubmit={handleSignUp} className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500 overflow-y-auto max-h-[600px] pr-2 custom-scrollbar">
      <div>
        <h3 className="text-2xl font-bold text-slate-800 mb-2">Create Account</h3>
        <p className="text-slate-500 text-sm">Join the MedTrack Pro network today.</p>
      </div>

      {error && (
        <div className="p-3 bg-rose-50 text-rose-600 text-xs font-bold rounded-lg border border-rose-100">
          {error}
        </div>
      )}

      <div>
        <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Registering As</label>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {(Object.values(UserRole)).map(r => (
            <button
              key={r}
              type="button"
              onClick={() => setRole(r)}
              className={`py-3 px-2 rounded-xl border-2 text-xs font-bold transition-all flex flex-col items-center gap-1 ${
                role === r 
                  ? 'bg-blue-50 border-blue-600 text-blue-600' 
                  : 'bg-white border-slate-100 text-slate-400 hover:border-slate-200'
              }`}
            >
              <RoleIcon role={r} />
              {r.charAt(0) + r.slice(1).toLowerCase()}
            </button>
          ))}
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Full Name</label>
          <input 
            type="text" 
            placeholder="John Smith" 
            className="w-full p-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none"
            value={formData.name}
            onChange={(e) => setFormData({...formData, name: e.target.value})}
            required
          />
        </div>
        <div>
          <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Email</label>
          <input 
            type="email" 
            placeholder="john@example.com" 
            className="w-full p-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none"
            value={formData.email}
            onChange={(e) => setFormData({...formData, email: e.target.value})}
            required
          />
        </div>
      </div>

      {role === UserRole.DOCTOR && (
        <div className="animate-in slide-in-from-top-2 duration-300">
          <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Medical Specialty</label>
          <select 
            className="w-full p-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
            value={formData.specialty}
            onChange={(e) => setFormData({...formData, specialty: e.target.value as DoctorCategory})}
          >
            {Object.values(DoctorCategory).map(cat => <option key={cat} value={cat}>{cat}</option>)}
          </select>
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Password</label>
          <input 
            type="password" 
            placeholder="••••••••" 
            className="w-full p-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none"
            value={formData.password}
            onChange={(e) => setFormData({...formData, password: e.target.value})}
            required
          />
        </div>
        <div>
          <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Confirm Password</label>
          <input 
            type="password" 
            placeholder="••••••••" 
            className="w-full p-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none"
            value={formData.confirmPassword}
            onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
            required
          />
        </div>
      </div>

      <button 
        type="submit" 
        className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-xl font-bold text-lg shadow-xl shadow-blue-100 transition-all mt-4"
      >
        Complete Registration
      </button>
    </form>
  );
};

const RoleIcon = ({ role }: { role: UserRole }) => {
  switch (role) {
    case UserRole.PATIENT: return <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>;
    case UserRole.DOCTOR: return <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>;
    case UserRole.ADMIN: return <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /></svg>;
    case UserRole.LAB: return <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.675.337a6 6 0 00-3.86.517l-2.387.477a2 2 0 00-1.022.547l-1.428 1.428A2 2 0 004.428 21h15.144a2 2 0 001.428-3.428l-1.428-1.428zM12 2v10m0 0l-3-3m3 3l3-3" /></svg>;
  }
};

export default SignUp;
