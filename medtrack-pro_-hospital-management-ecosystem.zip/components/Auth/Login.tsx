
import React, { useState } from 'react';
import { useApp } from '../../App';

const Login: React.FC = () => {
  const { users, setCurrentUser } = useApp();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    
    // Simple mock authentication
    if (user) {
      setCurrentUser(user);
    } else {
      setError('No user found with this email. Please sign up.');
    }
  };

  return (
    <form onSubmit={handleLogin} className="space-y-5 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h3 className="text-2xl font-bold text-slate-800 mb-2">Welcome Back</h3>
        <p className="text-slate-500 text-sm">Enter your credentials to access your hospital portal.</p>
      </div>

      {error && (
        <div className="p-3 bg-rose-50 text-rose-600 text-xs font-bold rounded-lg border border-rose-100">
          {error}
        </div>
      )}

      <div>
        <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Email Address</label>
        <input 
          type="email" 
          placeholder="doctor@medtrack.com" 
          className="w-full p-4 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
      </div>

      <div>
        <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Password</label>
        <input 
          type="password" 
          placeholder="••••••••" 
          className="w-full p-4 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
      </div>

      <div className="flex items-center justify-between text-sm">
        <label className="flex items-center gap-2 text-slate-600 cursor-pointer">
          <input type="checkbox" className="rounded text-blue-600" />
          <span>Remember me</span>
        </label>
        <button type="button" className="text-blue-600 font-semibold hover:underline">Forgot Password?</button>
      </div>

      <button 
        type="submit" 
        className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-xl font-bold text-lg shadow-xl shadow-blue-100 transition-all transform hover:-translate-y-0.5"
      >
        Sign In to Portal
      </button>
      
      <div className="pt-4 border-t border-slate-50">
        <p className="text-center text-slate-400 text-xs">
          Use demo accounts: john@example.com (Patient), sarah@medtrack.com (Doctor), admin@medtrack.com (Admin)
        </p>
      </div>
    </form>
  );
};

export default Login;
