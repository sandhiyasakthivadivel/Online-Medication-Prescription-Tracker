
import React, { useState } from 'react';
import { useApp } from '../../App';

const LabDashboard: React.FC = () => {
  const { labTests, setLabTests } = useApp();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [resultInput, setResultInput] = useState('');

  const pendingTests = labTests.filter(t => t.status === 'REQUESTED');
  const completedTests = labTests.filter(t => t.status === 'COMPLETED');

  const handleUpdateResult = (testId: string) => {
    setLabTests(prev => prev.map(t => 
      t.id === testId ? { ...t, status: 'COMPLETED', results: resultInput } : t
    ));
    setEditingId(null);
    setResultInput('');
  };

  return (
    <div className="max-w-6xl mx-auto p-4 md:p-8">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-2xl font-bold text-slate-800">Laboratory Queue</h2>
        <div className="flex gap-4">
          <div className="bg-purple-100 text-purple-700 px-4 py-2 rounded-xl text-sm font-bold">
            {pendingTests.length} Pending
          </div>
          <div className="bg-slate-100 text-slate-600 px-4 py-2 rounded-xl text-sm font-bold">
            {completedTests.length} Completed
          </div>
        </div>
      </div>

      <div className="grid gap-6">
        {pendingTests.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-2xl border border-dashed border-slate-300 text-slate-400">
            No pending test requests.
          </div>
        ) : (
          pendingTests.map(test => (
            <div key={test.id} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
              <div className="flex flex-col md:flex-row justify-between gap-6">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="w-2 h-2 rounded-full bg-purple-600 animate-pulse"></span>
                    <h3 className="text-lg font-bold text-slate-800">{test.testName}</h3>
                  </div>
                  <p className="text-sm text-slate-500">Requested for Patient #{test.patientId.slice(0, 8)}</p>
                  <p className="text-xs text-slate-400">Date: {test.requestedAt}</p>
                </div>
                
                {editingId === test.id ? (
                  <div className="flex-1 max-w-lg space-y-3">
                    <textarea 
                      className="w-full p-3 text-sm rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-400 outline-none h-24"
                      placeholder="Enter clinical test results..."
                      value={resultInput}
                      onChange={(e) => setResultInput(e.target.value)}
                    />
                    <div className="flex gap-2">
                      <button 
                        onClick={() => handleUpdateResult(test.id)}
                        className="bg-purple-600 text-white px-6 py-2 rounded-lg font-bold text-sm"
                      >
                        Submit Results
                      </button>
                      <button 
                        onClick={() => setEditingId(null)}
                        className="bg-slate-100 text-slate-500 px-6 py-2 rounded-lg font-bold text-sm"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <button 
                    onClick={() => setEditingId(test.id)}
                    className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-3 rounded-xl font-bold transition-all shadow-lg shadow-purple-100"
                  >
                    Enter Results
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {completedTests.length > 0 && (
        <div className="mt-12">
          <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Recently Completed</h3>
          <div className="space-y-4 opacity-70">
            {completedTests.map(test => (
              <div key={test.id} className="bg-white p-4 rounded-xl border border-slate-100 flex justify-between items-center">
                <div>
                  <h4 className="font-bold text-slate-700">{test.testName}</h4>
                  <p className="text-xs text-slate-500">Patient: {test.patientId} | Results provided</p>
                </div>
                <div className="text-xs font-bold text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full">✓ COMPLETED</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default LabDashboard;
