
import React, { useState } from 'react';
import { useApp } from '../../App';
import { AppointmentStatus, MedicalRecord, Prescription, Appointment } from '../../types';
import { suggestDiagnosis } from '../../services/geminiService';

const DoctorDashboard: React.FC = () => {
  const { currentUser, appointments, setAppointments, records, setRecords, setLabTests, setBills } = useApp();
  const [activeApp, setActiveApp] = useState<Appointment | null>(null);
  const [diagnosis, setDiagnosis] = useState('');
  const [notes, setNotes] = useState('');
  const [prescriptions, setPrescriptions] = useState<Prescription[]>([]);
  const [newMedicine, setNewMedicine] = useState({ medicine: '', dosage: '', frequency: '' });
  const [labTestsNeeded, setLabTestsNeeded] = useState<string[]>([]);
  const [isAiSuggesting, setIsAiSuggesting] = useState(false);

  const myAppointments = appointments.filter(a => a.doctorId === currentUser?.id && a.status === AppointmentStatus.CONFIRMED);

  const addPrescription = () => {
    if (!newMedicine.medicine) return;
    setPrescriptions(prev => [...prev, newMedicine]);
    setNewMedicine({ medicine: '', dosage: '', frequency: '' });
  };

  const handleAiSuggest = async () => {
    if (!notes) return alert("Please enter some symptoms/notes first.");
    setIsAiSuggesting(true);
    const result = await suggestDiagnosis(notes);
    if (result) {
      setDiagnosis(result.diagnosis || '');
      setPrescriptions(result.suggestions || []);
    }
    setIsAiSuggesting(false);
  };

  const handleComplete = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeApp) return;

    const newRecord: MedicalRecord = {
      id: Math.random().toString(36).substr(2, 9),
      patientId: activeApp.patientId,
      appointmentId: activeApp.id,
      diagnosis,
      notes,
      prescriptions,
      updatedAt: new Date().toLocaleDateString(),
    };

    setRecords(prev => [...prev, newRecord]);

    // Create Lab Tests if needed
    labTestsNeeded.forEach(test => {
      setLabTests(prev => [...prev, {
        id: Math.random().toString(36).substr(2, 9),
        appointmentId: activeApp.id,
        patientId: activeApp.patientId,
        testName: test,
        status: 'REQUESTED',
        requestedAt: new Date().toLocaleDateString(),
        cost: 50 // Mock cost
      }]);
    });

    // Create Bill
    const labTotal = labTestsNeeded.length * 50;
    setBills(prev => [...prev, {
      id: Math.random().toString(36).substr(2, 9),
      patientId: activeApp.patientId,
      appointmentId: activeApp.id,
      consultationFee: 100, // Mock fixed fee
      labFees: labTotal,
      total: 100 + labTotal,
      isPaid: false,
      date: new Date().toLocaleDateString(),
    }]);

    // Update appointment status
    setAppointments(prev => prev.map(a => a.id === activeApp.id ? { ...a, status: AppointmentStatus.COMPLETED } : a));
    setActiveApp(null);
    setDiagnosis('');
    setNotes('');
    setPrescriptions([]);
    setLabTestsNeeded([]);
  };

  const commonLabTests = ['Complete Blood Count (CBC)', 'Lipid Profile', 'Blood Sugar Fasting', 'ECG', 'X-Ray Chest'];

  return (
    <div className="max-w-6xl mx-auto p-4 md:p-8">
      {!activeApp ? (
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-slate-800">Your Consultations Today</h2>
          <div className="grid gap-4">
            {myAppointments.length === 0 ? (
              <div className="text-center py-12 text-slate-400 bg-white rounded-2xl border border-slate-200">
                All caught up! No scheduled appointments.
              </div>
            ) : (
              myAppointments.map(app => (
                <div key={app.id} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex justify-between items-center">
                  <div>
                    <h4 className="font-bold text-slate-800">Patient #{app.patientId.slice(0, 5)}</h4>
                    <p className="text-sm text-slate-500">Scheduled: {app.timeSlot} on {app.preferredDate}</p>
                  </div>
                  <button 
                    onClick={() => setActiveApp(app)}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-2 rounded-xl font-bold transition-all shadow-md shadow-emerald-100"
                  >
                    Start Consultation
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="bg-emerald-600 p-6 text-white flex justify-between items-center">
            <div>
              <h2 className="text-xl font-bold">Consultation Session</h2>
              <p className="text-emerald-100 text-sm opacity-90">Patient: {activeApp.patientId} | Category: {activeApp.doctorCategory}</p>
            </div>
            <button onClick={() => setActiveApp(null)} className="text-emerald-100 hover:text-white">Exit Consultation</button>
          </div>
          
          <form onSubmit={handleComplete} className="p-8 space-y-8">
            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Clinical Notes & Symptoms</label>
                  <textarea 
                    className="w-full h-32 p-4 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 outline-none resize-none"
                    placeholder="Describe patient condition, vitals, and concerns..."
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    required
                  />
                  <button 
                    type="button" 
                    onClick={handleAiSuggest}
                    disabled={isAiSuggesting}
                    className="mt-2 text-xs font-bold text-emerald-600 flex items-center gap-2 hover:underline"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                    {isAiSuggesting ? 'Analyzing...' : 'AI Suggest Diagnosis'}
                  </button>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Formal Diagnosis</label>
                  <input 
                    type="text" 
                    className="w-full p-4 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 outline-none"
                    placeholder="e.g. Acute Bronchitis"
                    value={diagnosis}
                    onChange={(e) => setDiagnosis(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="space-y-4">
                <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Prescriptions</label>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-4">
                  <div className="grid grid-cols-3 gap-2">
                    <input type="text" placeholder="Medicine" className="p-2 text-sm rounded border" value={newMedicine.medicine} onChange={e => setNewMedicine({...newMedicine, medicine: e.target.value})} />
                    <input type="text" placeholder="Dosage" className="p-2 text-sm rounded border" value={newMedicine.dosage} onChange={e => setNewMedicine({...newMedicine, dosage: e.target.value})} />
                    <input type="text" placeholder="Frequency" className="p-2 text-sm rounded border" value={newMedicine.frequency} onChange={e => setNewMedicine({...newMedicine, frequency: e.target.value})} />
                  </div>
                  <button type="button" onClick={addPrescription} className="w-full bg-slate-800 text-white py-2 rounded font-bold text-sm">+ Add Medicine</button>
                  
                  <div className="space-y-2 mt-4 max-h-40 overflow-y-auto">
                    {prescriptions.map((p, i) => (
                      <div key={i} className="flex justify-between items-center bg-white p-2 rounded border text-sm">
                        <span><strong>{p.medicine}</strong> - {p.dosage} ({p.frequency})</span>
                        <button type="button" onClick={() => setPrescriptions(prescriptions.filter((_, idx) => idx !== i))} className="text-rose-500">×</button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="border-t border-slate-100 pt-8">
              <label className="block text-xs font-bold text-slate-400 uppercase mb-3">Order Laboratory Tests</label>
              <div className="flex flex-wrap gap-2">
                {commonLabTests.map(test => (
                  <button 
                    key={test}
                    type="button"
                    onClick={() => setLabTestsNeeded(prev => prev.includes(test) ? prev.filter(t => t !== test) : [...prev, test])}
                    className={`px-4 py-2 rounded-full text-xs font-bold transition-all ${labTestsNeeded.includes(test) ? 'bg-purple-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
                  >
                    {test}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex justify-end pt-4">
              <button 
                type="submit" 
                className="bg-emerald-600 hover:bg-emerald-700 text-white px-12 py-4 rounded-2xl font-bold text-lg shadow-xl shadow-emerald-100 transition-all"
              >
                Complete Consultation & Update Records
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default DoctorDashboard;
