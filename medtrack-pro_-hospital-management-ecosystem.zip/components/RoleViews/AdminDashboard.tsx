
import React, { useState } from 'react';
import { useApp } from '../../App';
import { AppointmentStatus, UserRole } from '../../types';

const AdminDashboard: React.FC = () => {
  const { appointments, setAppointments, users } = useApp();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [selectedSlot, setSelectedSlot] = useState('09:00 AM');
  const [adminNote, setAdminNote] = useState('');

  const pendingAppointments = appointments.filter(a => a.status === AppointmentStatus.PENDING);
  const confirmedAppointments = appointments.filter(a => a.status === AppointmentStatus.CONFIRMED);

  const handleConfirm = (appId: string) => {
    const targetAppointment = appointments.find(a => a.id === appId);
    if (!targetAppointment) return;

    // Find a doctor with the required specialty from the REAL users list
    const doctorInSpec = users.find(u => 
      u.role === UserRole.DOCTOR && u.specialty === targetAppointment.doctorCategory
    );

    setAppointments(prev => prev.map(a => 
      a.id === appId 
        ? { ...a, status: AppointmentStatus.CONFIRMED, timeSlot: selectedSlot, adminNotes: adminNote, doctorId: doctorInSpec?.id } 
        : a
    ));
    setEditingId(null);
    setSelectedSlot('09:00 AM');
    setAdminNote('');
  };

  const timeSlots = [
    '09:00 AM', '10:00 AM', '11:00 AM', '12:00 PM', 
    '02:00 PM', '03:00 PM', '04:00 PM', '05:00 PM'
  ];

  return (
    <div className="max-w-6xl mx-auto p-4 md:p-8">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-10">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 text-center">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Total Requests</p>
          <p className="text-4xl font-black text-blue-600">{appointments.length}</p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 text-center">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Awaiting Slots</p>
          <p className="text-4xl font-black text-amber-500">{pendingAppointments.length}</p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 text-center">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Confirmed</p>
          <p className="text-4xl font-black text-emerald-500">{confirmedAppointments.length}</p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 text-center">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Total Patients</p>
          <p className="text-4xl font-black text-slate-800">{users.filter(u => u.role === UserRole.PATIENT).length}</p>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200">
          <h2 className="text-lg font-bold text-slate-800">Appointment Management Queue</h2>
        </div>
        <div className="divide-y divide-slate-100">
          {pendingAppointments.length === 0 ? (
            <div className="p-12 text-center text-slate-400">No pending requests at this time.</div>
          ) : (
            pendingAppointments.map(app => (
              <div key={app.id} className="p-6 transition-all hover:bg-blue-50/30">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center font-bold">
                      {app.doctorCategory[0]}
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-800">{app.doctorCategory} Appointment</h4>
                      <p className="text-sm text-slate-500">Requested for {app.preferredDate}</p>
                      <p className="text-xs text-slate-400 font-mono">Patient ID: {app.patientId}</p>
                    </div>
                  </div>
                  
                  {editingId === app.id ? (
                    <div className="w-full md:w-auto flex flex-col md:flex-row items-end gap-3 p-4 bg-blue-50 rounded-xl">
                      <div className="w-full md:w-40">
                        <label className="text-[10px] font-black text-blue-600 uppercase mb-1 block">Assign Time</label>
                        <select 
                          className="w-full p-2 text-sm rounded border border-blue-200"
                          value={selectedSlot}
                          onChange={(e) => setSelectedSlot(e.target.value)}
                        >
                          {timeSlots.map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                      </div>
                      <div className="w-full md:w-60">
                        <label className="text-[10px] font-black text-blue-600 uppercase mb-1 block">Quick Note</label>
                        <input 
                          type="text" 
                          placeholder="Room 302, Building A" 
                          className="w-full p-2 text-sm rounded border border-blue-200"
                          value={adminNote}
                          onChange={(e) => setAdminNote(e.target.value)}
                        />
                      </div>
                      <div className="flex gap-2">
                        <button 
                          onClick={() => handleConfirm(app.id)}
                          className="bg-blue-600 text-white px-4 py-2 rounded text-sm font-bold"
                        >
                          Confirm
                        </button>
                        <button 
                          onClick={() => setEditingId(null)}
                          className="bg-slate-200 text-slate-600 px-4 py-2 rounded text-sm font-bold"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button 
                      onClick={() => setEditingId(app.id)}
                      className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-xl font-bold transition-all shadow-md shadow-blue-100"
                    >
                      Process Slot
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
