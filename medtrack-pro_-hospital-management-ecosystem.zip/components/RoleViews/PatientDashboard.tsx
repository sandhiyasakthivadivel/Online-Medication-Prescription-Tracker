
import React, { useState } from 'react';
import { useApp } from '../../App';
import { DoctorCategory, AppointmentStatus, Appointment, Bill } from '../../types';
import { generatePrescriptionSummary } from '../../services/geminiService';

const PatientDashboard: React.FC = () => {
  const { currentUser, appointments, setAppointments, records, bills, setBills } = useApp();
  const [activeTab, setActiveTab] = useState<'appointments' | 'records' | 'billing'>('appointments');
  const [showBooking, setShowBooking] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<DoctorCategory>(DoctorCategory.GENERAL);
  const [selectedDate, setSelectedDate] = useState('');
  const [aiSummaries, setAiSummaries] = useState<Record<string, string>>({});
  const [loadingSummary, setLoadingSummary] = useState<string | null>(null);

  const myAppointments = appointments.filter(a => a.patientId === currentUser?.id);
  const myRecords = records.filter(r => r.patientId === currentUser?.id);
  const myBills = bills.filter(b => b.patientId === currentUser?.id);

  const handleBook = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDate) return;

    const newAppointment: Appointment = {
      id: Math.random().toString(36).substr(2, 9),
      patientId: currentUser!.id,
      doctorCategory: selectedCategory,
      preferredDate: selectedDate,
      status: AppointmentStatus.PENDING,
    };

    setAppointments(prev => [...prev, newAppointment]);
    setShowBooking(false);
    setSelectedDate('');
  };

  const handlePay = (billId: string) => {
    setBills(prev => prev.map(b => b.id === billId ? { ...b, isPaid: true } : b));
    alert("Payment Successful! Mock payment processed via Online Gateway.");
  };

  const getSummary = async (recordId: string, diagnosis: string, prescriptions: any[]) => {
    setLoadingSummary(recordId);
    const summary = await generatePrescriptionSummary(diagnosis, prescriptions);
    setAiSummaries(prev => ({ ...prev, [recordId]: summary || '' }));
    setLoadingSummary(null);
  };

  return (
    <div className="max-w-6xl mx-auto p-4 md:p-8">
      <div className="flex flex-col md:flex-row gap-6 mb-8">
        <div className="flex-1 bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h2 className="text-2xl font-bold text-slate-800 mb-4">Welcome back, {currentUser?.name}</h2>
          <div className="flex gap-4">
            <button 
              onClick={() => { setActiveTab('appointments'); setShowBooking(true); }}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-medium transition-all shadow-lg shadow-blue-200"
            >
              New Appointment
            </button>
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex flex-col items-center justify-center">
            <span className="text-3xl font-bold text-blue-600">{myAppointments.length}</span>
            <span className="text-xs text-slate-500 font-medium">Appointments</span>
          </div>
          <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex flex-col items-center justify-center">
            <span className="text-3xl font-bold text-emerald-600">{myRecords.length}</span>
            <span className="text-xs text-slate-500 font-medium">Medical Records</span>
          </div>
          <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex flex-col items-center justify-center">
            <span className="text-3xl font-bold text-amber-600">{myBills.filter(b => !b.isPaid).length}</span>
            <span className="text-xs text-slate-500 font-medium">Unpaid Bills</span>
          </div>
        </div>
      </div>

      <div className="flex border-b border-slate-200 mb-6 overflow-x-auto">
        {(['appointments', 'records', 'billing'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-6 py-3 font-medium text-sm transition-all whitespace-nowrap capitalize ${activeTab === tab ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-500 hover:text-slate-700'}`}
          >
            {tab}
          </button>
        ))}
      </div>

      {activeTab === 'appointments' && (
        <div className="space-y-4">
          {showBooking && (
            <div className="bg-blue-50 border border-blue-100 p-6 rounded-2xl mb-6">
              <h3 className="text-lg font-bold text-blue-800 mb-4">Request Doctor Appointment</h3>
              <form onSubmit={handleBook} className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-blue-600 mb-1 uppercase">Specialty</label>
                  <select 
                    className="w-full p-3 rounded-lg border border-blue-200 focus:ring-2 focus:ring-blue-400 outline-none"
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value as DoctorCategory)}
                  >
                    {Object.values(DoctorCategory).map(cat => <option key={cat} value={cat}>{cat}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-blue-600 mb-1 uppercase">Preferred Date</label>
                  <input 
                    type="date" 
                    className="w-full p-3 rounded-lg border border-blue-200 focus:ring-2 focus:ring-blue-400 outline-none"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    required
                  />
                </div>
                <div className="flex items-end">
                  <button type="submit" className="w-full bg-blue-600 text-white py-3 rounded-lg font-bold hover:bg-blue-700 transition-all">
                    Send Request to Admin
                  </button>
                </div>
              </form>
            </div>
          )}

          {myAppointments.length === 0 ? (
            <div className="text-center py-12 text-slate-400 bg-white rounded-2xl border border-dashed border-slate-300">
              No appointments found. Book one to get started.
            </div>
          ) : (
            myAppointments.map(app => (
              <div key={app.id} className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-start gap-4">
                  <div className={`p-3 rounded-xl ${app.status === AppointmentStatus.CONFIRMED ? 'bg-emerald-100 text-emerald-600' : 'bg-blue-100 text-blue-600'}`}>
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-800">{app.doctorCategory}</h4>
                    <p className="text-sm text-slate-500">Date: {app.preferredDate} {app.timeSlot && `• Time: ${app.timeSlot}`}</p>
                    {app.adminNotes && <p className="text-xs text-amber-600 bg-amber-50 px-2 py-1 rounded mt-1">{app.adminNotes}</p>}
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                    app.status === AppointmentStatus.PENDING ? 'bg-amber-100 text-amber-600' :
                    app.status === AppointmentStatus.CONFIRMED ? 'bg-emerald-100 text-emerald-600' :
                    app.status === AppointmentStatus.COMPLETED ? 'bg-slate-100 text-slate-600' :
                    'bg-rose-100 text-rose-600'
                  }`}>
                    {app.status}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {activeTab === 'records' && (
        <div className="space-y-6">
          {myRecords.length === 0 ? (
            <div className="text-center py-12 text-slate-400 bg-white rounded-2xl border border-dashed border-slate-300">
              No medical records available yet.
            </div>
          ) : (
            myRecords.map(record => (
              <div key={record.id} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-bold text-slate-800">Diagnosis: {record.diagnosis}</h3>
                    <p className="text-sm text-slate-500">Recorded on {record.updatedAt}</p>
                  </div>
                  <button 
                    onClick={() => getSummary(record.id, record.diagnosis, record.prescriptions)}
                    disabled={loadingSummary === record.id}
                    className="flex items-center gap-2 text-xs font-bold text-blue-600 bg-blue-50 px-3 py-2 rounded-lg hover:bg-blue-100"
                  >
                    {loadingSummary === record.id ? 'Thinking...' : 'AI Explain Record'}
                  </button>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-2">Doctor Notes</h4>
                    <p className="text-slate-700 leading-relaxed whitespace-pre-wrap">{record.notes}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-2">Prescriptions</h4>
                    <div className="space-y-2">
                      {record.prescriptions.map((p, idx) => (
                        <div key={idx} className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                          <p className="font-bold text-slate-800">{p.medicine}</p>
                          <p className="text-xs text-slate-500">{p.dosage} — {p.frequency}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {aiSummaries[record.id] && (
                  <div className="mt-6 p-4 bg-emerald-50 border border-emerald-100 rounded-xl">
                    <h5 className="text-xs font-bold text-emerald-600 uppercase mb-1">MedTrack AI Summary</h5>
                    <p className="text-emerald-800 text-sm italic">"{aiSummaries[record.id]}"</p>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      )}

      {activeTab === 'billing' && (
        <div className="space-y-4">
          {myBills.length === 0 ? (
            <div className="text-center py-12 text-slate-400 bg-white rounded-2xl border border-dashed border-slate-300">
              No billing history found.
            </div>
          ) : (
            myBills.map(bill => (
              <div key={bill.id} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col md:flex-row justify-between items-center gap-6">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-1">
                    <h4 className="font-bold text-slate-800">Bill ID: #{bill.id.slice(0, 8)}</h4>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${bill.isPaid ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>
                      {bill.isPaid ? 'PAID' : 'UNPAID'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">Date: {bill.date}</p>
                  <div className="mt-3 grid grid-cols-2 gap-4">
                    <div className="text-xs">
                      <span className="text-slate-400 block">Consultation</span>
                      <span className="font-semibold text-slate-700">${bill.consultationFee}</span>
                    </div>
                    <div className="text-xs">
                      <span className="text-slate-400 block">Lab Tests</span>
                      <span className="font-semibold text-slate-700">${bill.labFees}</span>
                    </div>
                  </div>
                </div>
                <div className="text-center md:text-right">
                  <p className="text-xs text-slate-400 mb-1 uppercase tracking-wider">Total Amount</p>
                  <p className="text-3xl font-bold text-slate-800">${bill.total}</p>
                  {!bill.isPaid && (
                    <button 
                      onClick={() => handlePay(bill.id)}
                      className="mt-3 px-8 py-2 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-100"
                    >
                      Pay Online
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};

export default PatientDashboard;
